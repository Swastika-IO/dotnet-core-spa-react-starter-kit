﻿
namespace SkiShopReact.ViewModels
{
    public class OrderGetVM
    {
        public int OrderId { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
        public decimal TotalValue { get; set; }

        public string Date { get; set; }

    }
}
