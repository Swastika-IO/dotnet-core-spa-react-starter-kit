﻿using System.Collections.Generic;

namespace SkiShopReact.ViewModels
{
    public class OrderVM
    {
        public int OrderId { get; set; }
        public List<string> StyleNos { get; set; }
    }
}
