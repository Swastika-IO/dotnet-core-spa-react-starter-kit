﻿
namespace SkiShopReact.Models
{
    public class StyleIdealFor
    {
        public int StyleId { get; set; }
        public Style Style { get; set; }

        public int IdealForId { get; set; }
        public IdealFor IdealFor { get; set; }

    }
}
